export default function Placeholder() {
  return <div>AS FASHIONS — component placeholder</div>;
}
